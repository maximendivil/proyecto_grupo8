<?php
	require("../vista/menuConfiguracion.html");
?>