<?php
	header("Location: controlador/index.php");
?>