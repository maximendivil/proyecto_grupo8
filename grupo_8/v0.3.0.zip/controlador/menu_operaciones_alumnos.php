<?php
	require("../vista/menu_operaciones_alumnos.html");
?>