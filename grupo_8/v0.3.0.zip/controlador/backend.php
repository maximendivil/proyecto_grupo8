<?php
	session_start();

	require("../modelo/modelo_funciones.php");
        require("controlador_funcionesDeVerificacion.php");

	function controlarRoles($rol,$requerimiento){
		switch ($requerimiento) {
			case 'menuCuotas':
				if ($rol == "consulta"){
					return false; //Esto no debería devolver "True"?
				}
				else {
					return true;
				}
				break;
			case 'menuUsuarios':
				if ($rol == "administracion"){
					return true;
				}
				else {
					return false;
				}
				break;
			case 'menuAlumnos':
				if ($rol == "administracion"){
					return true;
				}
				else {
					return false;
				}
				break;
                        case 'menuResponsables':
				if ($rol == "administracion"){
					return true;
				}
				else {
					return false;
				}
				break;
			case 'menuConfig':
				if ($rol == "administracion"){
					return true;
				}
				else {
					return false;
				}
				break;
			case 'menuListados':
				return true;
				
				break;
			
			default:
				return false;
				break;
		}
	}

	if (isset($_SESSION["usuario"])){
                
		$titulo = obtenerInformacionTitulo();
		if (isset($_GET["controller"])){
			$requerimiento = $_GET["controller"];
			switch ($requerimiento) {
				case 'menuCuotas':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("../vista/menuPagoCuotas.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'index':
					require("../vista/operaciones.html");
					break;
				case 'menuUsuarios':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("../vista/mi_cuenta.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'menuAlumnos':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("menu_operaciones_alumnos.php");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'menuConfig':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("menu_configuracion.php");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'menuListados':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("menu_listados.php");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
                                case 'menuResponsables':
					if (controlarRoles($_SESSION["rol"],$requerimiento)){
						require("../vista/menu_operaciones_responsables.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'agregarUsuario':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
						require("../vista/registrarse.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'listadosMatriculasPagas':
					if (controlarRoles($_SESSION["rol"],"menuListados")){
						$pagina = $_GET["pagina"];
						require("listadoDeAlumnosConMatriculaPaga.php");
						obtenerMatriculasPagas($pagina);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'listadoDeCuotasImpagas':
					if (controlarRoles($_SESSION["rol"],"menuListados")){
						$pagina = $_GET["pagina"];
						require("listadoDeCuotasImpagasPorAoM.php");
						listadoDeCuotasImpagas($pagina);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'listadoDeCuotasPagas':
					if (controlarRoles($_SESSION["rol"],"menuListados")){
						$pagina = $_GET["pagina"];
						require("listadoDeCuotasPoBporAoM.php");
						listadoDeCuotasPagas($pagina);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'informacionConfig':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
						$titulo = obtenerInformacionTitulo();
						$email = obtenerInformacionMail();
						$telefono = obtenerInformacionTelefono();

						require("../vista/informacion.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'establecerInformacion':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
                                            if ((isset($_POST["tit"])) && (isset($_POST["mail"])) && (isset($_POST["tel"])) && verificarCamposInformacion($_POST["tit"], $_POST["mail"], $_POST["tel"])){                                                                            
						$titulo = establecerInformacionTitulo($_POST["tit"]);
						$email = establecerInformacionMail($_POST["mail"]);
						$telefono = establecerInformacionTelefono($_POST["tel"]);
						header("Location: backend.php?controller=menuConfig");
                                            } else {
                                                $msjE = "No se pudo establecer la nueva información. Verifique que los datos que está ingresando sean válidos.";
                                                require("../vista/mensajeConfiguracion.html");
                                            }
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'paginacionConfig':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
						$paginacion = cantidadPaginacionSitio();
						require("../vista/paginacion.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'establecerPaginacion':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
                                            if (isset($_POST["pag"]) && verificarCamposPaginacion($_POST["pag"])){
						$paginacion = establecerPaginacion($_POST["pag"]);
						header("Location: backend.php?controller=menuConfig");
                                            } else {
                                                $msjE = "Error al tratar de establecer la paginación. Verifique que los datos ingresados sean válidos.";
                                                require '../vista/mensajeConfiguracion.html';
                                            }
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'habilitarSitioConfig':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
						$habilitado = verificarSitioHabilitado();
						require("../vista/habilitar_sitio.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'habilitarSitio':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
						if (isset($_POST["hab"])){
							$habilitado = habilitarSitio();
						}
						else {
							$habilitado = deshabilitarSitio();
						}
						header("Location: backend.php?controller=menuConfig");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'mensajeDeshabilitadoConfig':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
						$msj = verMensajeDeshabilitado();
						require("../vista/mensaje_deshabilitado.html");
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'mensajeDeshabilitado':
					if (controlarRoles($_SESSION["rol"],"menuConfig")){
                                            if (isset($_POST["msj"]) && verificarCamposMensajeDeshabilitado($_POST["msj"])){
						$msj = establecerMensajeDeshabilitado($_POST["msj"]);
						header("Location: backend.php?controller=menuConfig");
                                            } else {
                                                $msjE= "Error al tratar de establecer el nuevo mensaje de sitio deshabilitado. Verifique que los datos ingresados son válidos.";
                                                require '../vista/mensajeConfiguracion.html';
                                            }
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'agregarUsuarioDB':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            if (isset($_POST["user"]) && (isset($_POST["pass1"])) && (isset($_POST["mail"])) && (isset($_POST["rol"])) && (verificarCamposUsuario($_POST["user"], $_POST["pass1"], $_POST["mail"], $_POST["rol"]))){
						require("controlador_registrarse.php");
						agregarUsuario($titulo);
                                            } else {
                                                $msjExito = "El usuario no se pudo agregar. Verifique que los datos que ingresa sean válidos.";
                                                require ("../vista/exito.html");
                                            }
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
                                case 'deshabilitarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                        require("deshabilitar_alumno.php");
                                        deshabilitarAlumnoNM();
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'habilitarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                        require("habilitar_alumno.php");
                                        habilitarAlumnoNM();
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'formulario_agregarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                    require("../vista/formulario_agregarAlumno.html");
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'controlador_agregarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                        if (isset($_POST["dni"]) && (isset($_POST["apellido"])) && (isset($_POST["nombre"])) && (isset($_POST["fechaNac"])) && (isset($_POST["sexo"])) && (isset($_POST["mail"])) && (isset($_POST["direccion"])) && (isset($_POST["fechaIngreso"])) && verificarCamposAlumno($_POST["dni"],$_POST["apellido"],$_POST["nombre"],$_POST["fechaNac"],$_POST["sexo"],$_POST["mail"],$_POST["direccion"],$_POST["fechaIngreso"])){
                                            require("controlador_agregarAlumno.php");
                                            agregarAlumnoNM($titulo,$_POST["dni"],$_POST["apellido"],$_POST["nombre"],$_POST["fechaNac"], $_POST["sexo"],$_POST["mail"],$_POST["direccion"],$_POST["fechaIngreso"]);
                                        } else{
                                            $msjE = "Los datos ingresados no son válidos. Verifique que no quedaron campos obligatorios sin completar y que no ingresó caracteres inválidos o números en los campos 'Nombre' y 'Apellido";
                                            require ("../vista/mensajeAlumno.html");
                                        }
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'formulario_editarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                    $rows = obtenerAlumnoConId($_GET["id"]);
                                    if (count($rows)>0){
                                        require("../vista/formulario_editarAlumno.html");
                                        } else{
                                            die();
                                        }    
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'controlador_editarAlumno':
                                    if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                        if (isset($_POST["dni"]) && (isset($_POST["apellido"])) && (isset($_POST["nombre"])) && (isset($_POST["fechaNac"])) && (isset($_POST["sexo"])) && (isset($_POST["mail"])) && (isset($_POST["direccion"])) && (isset($_POST["fechaIngreso"])) && verificarCamposAlumno($_POST["dni"],$_POST["apellido"],$_POST["nombre"],$_POST["fechaNac"],$_POST["sexo"],$_POST["mail"],$_POST["direccion"],$_POST["fechaIngreso"])){
                                            require("controlador_editarAlumno.php");
                                            editarAlumnoNM($titulo,$_GET["idAlumno"],$_POST["dni"],$_POST["apellido"],$_POST["nombre"],$_POST["fechaNac"], $_POST["sexo"],$_POST["mail"],$_POST["direccion"],$_POST["fechaIngreso"]);
                                        }else{
                                            $msjE = "Los datos ingresados no son válidos. Verifique que no quedaron campos obligatorios sin completar y que no ingresó caracteres inválidos o números en los campos 'Nombre' y 'Apellido";
                                            require ("../vista/mensajeAlumno.html");
                                        }
                                    } else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
				case 'cambiarRoles':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
						$pagina = $_GET["pagina"];
						require("cambiar_roles.php");
						cambiarRoles($pagina);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'cambiarRol':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            if (isset($_GET["user"]) && isset($_POST["rol"]) && verificarCamposCambiarRol($_GET["user"], $_POST["rol"])){
						require("cambiar_rol.php");
						cambiarRol($_GET["user"]);
                                            }
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'formRol':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
						$user = $_GET["user"];
						require("../vista/cambiarRol.html");
						
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'eliminarUsuarios':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
						$pagina = $_GET["pagina"];
						require("eliminar_cuenta.php");
						eliminarUsuarios($pagina);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
				case 'eliminarUsuarioDB':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
						$user = $_GET["user"];
						$valor = $_GET["valor"];
						require("eliminar_usuario.php");
						eliminarUser($user,$valor);
					}
					else {
						require("../vista/operaciones.html");
					}
					break;
	                                
                                case 'formulario_AgregarCuota':
                                    if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                        require("../vista/formulario_AgregarCuotaAlumno.html");
                                    }
                                    else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'agregarCuotaDB':
                                    if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                        if ((isset($_POST["anioCuota"])) && (isset($_POST["mes"])) && (isset($_POST["numeroCuota"])) && (isset($_POST["monto"])) && (isset($_POST["tipoCuota"])) && (isset($_POST["comisionCobrador"])) && verificarCamposCuota($_POST["anioCuota"],$_POST["mes"], $_POST["numeroCuota"], $_POST["monto"], $_POST["tipoCuota"],$_POST["comisionCobrador"])){
                                            require("../controlador/controlador_agregarCuota.php");
                                            agregarCuotaNM($titulo);
                                        } else {
                                            $msjE= "La cuota no se pudo agregar. Verifique que los datos que está ingresando son válidos.";
                                            require "../vista/mensajeCuotas.html";
                                        }
                                    }
                                    else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'formulario_agregarResponsable':
                                    if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                        require("../vista/formulario_agregarResponsable.html");
                                    }
                                    else {
                                        require("../vista/operaciones.html");
                                    }
                                    break;
                                case 'controlador_agregarResponsableGeneral':
                                    if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                        if (isset($_POST["apellidoTutor"]) && (isset($_POST["nombreTutor"])) && (isset($_POST["tipoParentezco"])) && (isset($_POST["fechaNac"])) && (isset($_POST["sexo"])) && (isset($_POST["email"])) && (isset($_POST["tel"])) && (isset($_POST["direccion"])) && verificarCamposResponsable($_POST["apellidoTutor"],$_POST["nombreTutor"],$_POST["tipoParentezco"],$_POST["fechaNac"],$_POST["sexo"],$_POST["email"],$_POST["tel"],$_POST["direccion"])){
                                            require("controlador_agregarResponsableGeneral.php");
                                            agregarResponsableGeneral($titulo,$_POST["apellidoTutor"],$_POST["nombreTutor"],$_POST["tipoParentezco"],$_POST["fechaNac"],$_POST["sexo"],$_POST["email"],$_POST["tel"],$_POST["direccion"]);
                                        } else {
                                            $msjE = "El responsable no pudo ser agregado. Verifique que los datos que ingrese sean válidos.";
                                            require ("../vista/mensajeResponsables.html");
                                        }
                                    }
                                    else {
                                        require("../vista/operaciones.html");
                                    }
                                        break;
                                    case 'listado_editarResponsable':
                                        if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                            try{
                                                $pagina = $_GET["pagina"];
						$paginacion = cantidadPaginacionSitio();
						if (!$pagina) {
                                                    $inicio = 0;
                                                    $pagina = 1;
						}
						else {
                                                    $inicio = ($pagina - 1) * $paginacion;
                                                }
						$total = totalResponsables();
						$rows = obtenerResponsables($inicio,$paginacion);
						$total_paginas = ceil($total / $paginacion);
						}
                                            catch (Exception $e){
                                                $msjE = $e->getMessage();
                                            }
                                            //$rows = obtenerResponsables();
                                            finally {
                                                require("../vista/listadoResponsablesEditar.html");
                                            }	                    
                                        }
                                        else {
                                            require("../vista/operaciones.html");
                                        }
                                        break;
                                    case 'formulario_editarResponsable':
                                        if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                            $rows = obtenerResponsableConId($_GET["idResponsable"]);
                                            if (count($rows)>0){
                                                require("../vista/form_modificar_ResponsableDeAlumno.html");
                                            } else {
                                                die();
                                            }
                                        }
                                        else {
                                            require("../vista/operaciones.html");
                                        }
                                        break;
                                    case 'controlador_editarResponsable':
                                        if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                            if (isset($_POST["apellidoTutor"]) && (isset($_POST["nombreTutor"])) && (isset($_POST["tipoParentezco"])) && (isset($_POST["fechaNac"])) && (isset($_POST["sexo"])) && (isset($_POST["email"])) && (isset($_POST["tel"])) && (isset($_POST["direccion"])) && verificarCamposResponsable($_POST["apellidoTutor"],$_POST["nombreTutor"],$_POST["tipoParentezco"],$_POST["fechaNac"],$_POST["sexo"],$_POST["email"],$_POST["tel"],$_POST["direccion"])){
                                                require("controlador_editarResponsableGeneral.php");
                                                modificarResponsableDeAlumnoNM($titulo);
                                            } else {
                                                $msjE = "El responsable no pudo ser modificado. Verifique que los datos que ingrese sean válidos.";
                                                require ("../vista/mensajeResponsables.html");
                                            }
                                        }
                                        else {
                                            require("../vista/operaciones.html");
                                        }
                                        break;
                                    case 'listado_eliminarResponsable':
                                        if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                            try{
                                                $pagina = $_GET["pagina"];
                                                $paginacion = cantidadPaginacionSitio();
						if (!$pagina) {
                                                    $inicio = 0;
						    $pagina = 1;
						}
						else {
                                                    $inicio = ($pagina - 1) * $paginacion;
						}
                                                $total = totalResponsables();
                                                $rows = obtenerResponsables($inicio,$paginacion);
                                                $total_paginas = ceil($total / $paginacion);
						}
                                            catch (Exception $e){
						$msjE = $e->getMessage();
                                            }
                                            finally {
                                                require("../vista/listadoResponsablesEliminar.html");
                                            }	
                                        }
                                        else {
                                            require("../vista/operaciones.html");
                                        }
                                        break;
                                    case 'controlador_eliminarResponsableGeneral':
                                        if (controlarRoles($_SESSION["rol"],"menuResponsables")){
                                            require("controlador_eliminarResponsableGeneral.php");
                                            eliminarResponsable2NM($titulo,$_GET["idResponsable"]);
                                        }
                                        else {
                                            require("../vista/operaciones.html");
                                        }
                                        break;
                                    case 'agregarResponsableAUsuario':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            $pagina = $_GET["pagina"];
                                            $paginacion = cantidadPaginacionSitio();
                                            if (!$pagina) {
						$inicio = 0;
                                                $pagina = 1;
                                            }
                                            else {
                                                $inicio = ($pagina - 1) * $paginacion;
                                            }
                                            $total = totalUsuariosSinResponsable();
                                            $rows = usuariosSinResponsable($inicio,$paginacion);
                                            $total_paginas = ceil($total / $paginacion);
                                            //$rows = usuariosSinResponsable();
                                            require("../vista/listadoUsuariosSinResponsable.html");
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'agregarResponsableDB':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            $user = $_GET["user"];
                                            $idResponsable = $_GET["responsable"];
                                            require("agregarResponsable.php");
                                            insertResponsable($user,$idResponsable);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'vistaAgregarResponsable':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            $user = $_GET["user"];
                                            try {
						$pagina = $_GET["pagina"];
						$paginacion = cantidadPaginacionSitio();
						if (!$pagina) {
						    $inicio = 0;
						    $pagina = 1;
						}
						else {
                                                    $inicio = ($pagina - 1) * $paginacion;
						}
						$total = totalResponsablesDeAlumnosSinUsuario();
						$rows = obtenerResponsablesDeAlumnosSinUsuario($inicio,$paginacion);
						$total_paginas = ceil($total / $paginacion);
						//$rows = obtenerResponsablesDeAlumnosSinUsuario();
						}
                                            catch (Exception $e){
                                                $msjE = $e->getMessage();
                                            }
                                            finally{
                                                require("../vista/listadoResponsablesSinUsuario.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'listado_eliminarCuotas':
                                        if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $pagina = $_GET["pagina"];
                                            $paginacion = cantidadPaginacionSitio();
                                            if (!$pagina) {
						$inicio = 0;
						$pagina = 1;
                                            }
                                            else {
						$inicio = ($pagina - 1) * $paginacion;
                                            }
                                            $total = totalCuotas();
                                            $rows = obtenerCuotas($inicio,$paginacion);
                                            if (count($rows)>0){
                                                $total_paginas = ceil($total / $paginacion);
                                            } else {
                                                $msjE="No hay cuotas.";
                                            }
                                            require("../vista/listado_eliminarCuotas.html");
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'eliminarCuotaBD':
                                        if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $idCuota = $_GET["idCuota"];
                                            require("../controlador/controlador_eliminarCuota.php");
                                            eliminarCuotaNM($titulo, $idCuota);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'listado_editarCuotas':
                                        if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $pagina = $_GET["pagina"];
                                            $paginacion = cantidadPaginacionSitio();
                                            if (!$pagina) {
                                                $inicio = 0;
						$pagina = 1;
                                            }
                                            else {
                                                $inicio = ($pagina - 1) * $paginacion;
                                            }
                                            $total = totalCuotas();
                                            $rows = obtenerCuotas($inicio,$paginacion);
                                            if (count($rows)>0) {
                                                $total_paginas = ceil($total / $paginacion);
                                                //$rows = obtenerCuotas();
                                            } else{
                                                $msjE = "No hay cuotas.";
                                            }
                                            require("../vista/listado_editarCuotas.html");
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'formulario_editarCuota':
                                        if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $cuota = obtenerCuotaConId($_GET["idCuota"]);
                                            if(count($cuota)>0){
                                                require("../vista/formulario_editarCuota.html");
                                            } else{
                                                die();
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'editarCuotaBD':
                                        if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            if ((isset($_POST["anioCuota"])) && (isset($_POST["mes"])) && (isset($_POST["numeroCuota"])) && (isset($_POST["monto"])) && (isset($_POST["tipoCuota"])) && (isset($_POST["comisionCobrador"])) && verificarCamposCuota($_POST["anioCuota"],$_POST["mes"], $_POST["numeroCuota"], $_POST["monto"], $_POST["tipoCuota"],$_POST["comisionCobrador"])){
                                                require("../controlador/controlador_editarCuota.php");
                                                editarCuotaNM($titulo);
                                            } else {
                                                $msjE = "La cuota no pudo ser editada. Verifique que los datos que ingrese sean válidos.";
                                                require "../vista/mensajeCuotas.html";
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'verPagos':
					if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $pagina = $_GET["pagina"];
                                            $paginacion = cantidadPaginacionSitio();
                                            if (!$pagina) {
                                                $inicio = 0;
						$pagina = 1;
                                            }
                                            else {
                                                $inicio = ($pagina - 1) * $paginacion;
                                            }
                                            $total = totalAlumnos();
                                            $rows = obtenerAlumnos($inicio,$paginacion);
                                            $total_paginas = ceil($total / $paginacion);
                                            require("../vista/alumnosCuota.html");
                                            //insertResponsable($user,$idResponsable);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'verPagosAlumnos':
					if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $pagina = $_GET["pagina"];
                                            $paginacion = cantidadPaginacionSitio();
                                            if (!$pagina) {
                                                $inicio = 0;
						$pagina = 1;
                                            }
                                            else {
                                                $inicio = ($pagina - 1) * $paginacion;
                                            }
                                            $total = totalAlumnos();
                                            $rows = obtenerAlumnos($inicio,$paginacion);
                                            $total_paginas = ceil($total / $paginacion);
                                            require("../vista/alumnosCuotaPagas.html");
                                            //insertResponsable($user,$idResponsable);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'cobrarCuotas':
					if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $id = $_GET["id"];
                                            $pagina = $_GET["pagina"];
                                            require("pago_cuotas.php");
                                            obtenerCuotasAlumno($id,$pagina);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;			
                                    case 'verCuotas':
					if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            try {
                                                $id = $_GET["id"];
                                                $pagina = $_GET["pagina"];
                                                $paginacion = cantidadPaginacionSitio();
                                                if (!$pagina) {
                                                    $inicio = 0;
                                                    $pagina = 1;
                                                }
						else {
                                                    $inicio = ($pagina - 1) * $paginacion;
                                                }
						$total = totalCuotasPagas($id);
						$rowsPagas = buscarCuotasPagas($id,$inicio,$paginacion);
						$total_paginas = ceil($total / $paginacion);
                                            }
                                            catch (Exception $e){ 
                                                $msjE = $e->getMessage();						
                                            }
                                            finally {						
                                                require("../vista/cuotasPagas.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;	

                                    case 'cambiarResponsableAUsuario':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            try {
						$rows = obtenerUsuariosResponsables();						
                                            }
                                            catch (Exception $e) {
						$msjE = $e->getMessage();
                                            }
                                            finally {
                                                require("../vista/listadosCambiarResponsable.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'cambiarResponsable':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            try {
                                                $user =  $_GET["user"];
                                                $rows = obtenerResponsableUsuario($user);
						require("../vista/modificar_responsable.html");					
                                            }
                                            catch (Exception $e) {
                                                $msjE = $e->getMessage();
                                                require("../vista/listadosCambiarResponsable.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'cambiarResponsableDB':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            try {
                                                if (isset($_GET["user"]) && isset($_POST["apellidoTutor"]) && (isset($_POST["nombreTutor"])) && (isset($_POST["tipoParentezco"])) && (isset($_POST["fechaNac"])) && (isset($_POST["sexo"])) && (isset($_POST["email"])) && (isset($_POST["tel"])) && (isset($_POST["direccion"])) && verificarCamposResponsableUsuario($_GET["user"],$_POST["apellidoTutor"],$_POST["nombreTutor"],$_POST["tipoParentezco"],$_POST["fechaNac"],$_POST["sexo"],$_POST["email"],$_POST["tel"],$_POST["direccion"])){
                                                    $user = $_GET["user"];
                                                    $apellido = $_POST["apellidoTutor"];
                                                    $nombre = $_POST["nombreTutor"];
                                                    $tipo = $_POST["tipoParentezco"];
                                                    $fechaNac = $_POST["fechaNac"];
                                                    $sexo = $_POST["sexo"];
                                                    $mail = $_POST["email"];
                                                    $tel = $_POST["tel"];
                                                    $direccion = $_POST["direccion"];
                                                    modificarResponsable($user,$apellido,$nombre,$tipo,$fechaNac,$sexo,$mail,$tel,$direccion);
                                                    $msjExito = "El responsable fue modificado correctamente!";
                                                    require("../vista/exito.html");
                                                } else {
                                                    $msjExito = "El responsable no pudo ser modificado. Verifique que los datos ingresados sean válidos.";
                                                    require("../vista/exito.html");
                                                    }
						}
                                            catch (Exception $e) {
						$msjE = $e->getMessage();
						//header("Location: backend.php?controller=cambiarResponsable&user=$user");							
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'eliminarResponsableAUsuario':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            try {
                                                $rows = obtenerUsuariosResponsables();					
                                            }
                                            catch (Exception $e) {
						$msjE = $e->getMessage();
                                            }
                                            finally {
                                                require("../vista/listadosEliminarResponsable.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'eliminarResponsable':
					if (controlarRoles($_SESSION["rol"],"menuUsuarios")){
                                            try {
                                                $user = $_GET["user"];
						eliminarResponsable($user);
                                            }
                                            catch (Exception $e) {
                                                $msjE = $e->getMessage();
                                            }
                                            finally {
                                                header("Location: backend.php?controller=menuUsuarios");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'pagarCuotasAlumno':
					if (controlarRoles($_SESSION["rol"],"menuCuotas")){
                                            $id = $_GET["id"];
                                            require("pagarCuota.php");
                                            pagarCuotas($id);
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'listadosAlumnos':
					if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                            try {
						$pagina = $_GET["pagina"];
						$paginacion = cantidadPaginacionSitio();
						if (!$pagina) {
                                                    $inicio = 0;
                                                    $pagina = 1;
						}
                                                else {
                                                    $inicio = ($pagina - 1) * $paginacion;
                                                }
                                                $total = totalAlumnos();
                                                $rows = obtenerAlumnos($inicio,$paginacion);
                                                $total_paginas = ceil($total / $paginacion);
                                                //$rows = obtenerAlumnos();
                                            }
                                            catch (Exception $e) {
                                                $msjE = $e->getMessage();
                                            }
                                            finally{
                                                require("../vista/listadoAlumnos.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'agregarResponsableAlumno':
					if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                            try {
                                                $idAlumno=$_GET["idAlumno"];
                                                $rows = obtenerResponsablesQueNoSeanDe($idAlumno);
                                            }
                                            catch (Exception $e) {
                                            $msjE = $e->getMessage();
                                            }
                                            finally{
                                                    require("../vista/listadoResponsables.html");
                                                
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'agregarResponsableAlumnoDB':
					if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                            try {
                                                $idResponsable = $_GET["idResponsable"];
                                                $idAlumno = $_GET["idAlumno"];
                                                asignarAlumnoResponsable($idAlumno,$idResponsable);
                                                $msjE = "El responsable fue asignado correctamente al alumno!";
						require("../vista/exitoAlumno.html");
                                            }
                                            catch (Exception $e) {
                                            $msjE = $e->getMessage();
                                            require("../vista/errorAsignarResponsableAlumno.html");	
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'eliminarResponsableAlumno':
					if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                            try {
						$idAlumno=$_GET["idAlumno"];        
						$rows = obtenerResponsablesDe($idAlumno);
                                            }
                                            catch (Exception $e) {
                                                $msjE = $e->getMessage();
                                            }
                                            finally{
                                                    require("../vista/listadoResponsablesDeAlumnoEliminar.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    case 'eliminarResponsableAlumnoDB':
					if (controlarRoles($_SESSION["rol"],"menuAlumnos")){
                                            try {
                                                $idResponsable = $_GET["idResponsable"];
	    					$idAlumno = $_GET["idAlumno"];    
	    					eliminarAlumnoResponsable($idAlumno,$idResponsable);
	    					$msjE = "Operación realizada con éxito!";
						require("../vista/exitoAlumno.html");
                                            }
                                            catch (Exception $e) {
                                                $msjE = $e->getMessage();
                                                require("../vista/errorEliminarResponsableAlumno.html");
                                            }
					}
					else {
                                            require("../vista/operaciones.html");
					}
					break;
                                    default:
					require("../vista/operaciones.html");
					break;
                                    }	
                }
                else {
                    require("../vista/operaciones.html");
                }
		
		//require '../vista/operaciones.html';
        }
	else {
		header("Location: index.php");
	}
?>