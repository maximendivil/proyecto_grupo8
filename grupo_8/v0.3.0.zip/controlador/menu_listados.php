<?php
	require("../vista/menuListados.html");
?>