<?php
	session_start();

	require("../vista/modificar_pass.html");
?>