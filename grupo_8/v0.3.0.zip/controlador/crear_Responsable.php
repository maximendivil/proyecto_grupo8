<?php
	session_start();
	
	require("../vista/crear_responsable.html");
        
?>