<?php
	//Verifico que no entren directo por la url
	//Si entran directo por la url, estan evitando al controlador (backend.php)
	//Y pueden violar los roles
	if(!isset($_GET["controller"])){
		header("Location: backend.php?controller=index");
	}
	function agregarCuotaNM($titulo){
		$titulo = obtenerInformacionTitulo();
		try{
                    if ((isset($_POST["anioCuota"])) && (isset($_POST["mes"])) && (isset($_POST["numeroCuota"])) && (isset($_POST["monto"])) && (isset($_POST["tipoCuota"])) && (isset($_POST["comisionCobrador"])) && verificarCamposCuota($_POST["anioCuota"], $_POST["mes"], $_POST["numeroCuota"], $_POST["monto"], $_POST["tipoCuota"], $_POST["comisionCobrador"])){
			agregarCuota($_POST["anioCuota"],$_POST["mes"],$_POST["numeroCuota"],$_POST["monto"],$_POST["tipoCuota"],$_POST["comisionCobrador"]);
			$msjE = "La cuota se agreg&oacute; correctamente!";
                    } else {
                        $msjE = "La cuota no pudo ser agregada. Verifique que los datos que ingrese sean válidos.";
                    }
                    require "../vista/mensajeCuotas.html";
		}
		catch (Exception $e) {
		   	$msjE = $e->getMessage();
		   	require "../vista/mensajeCuotas.html";
		}
	}

	
?>