<?php
	session_start();
	require("../modelo/modelo_funciones.php");
	
	$usuario = $_POST["usuario"];
	$pass = $_POST["contraseña"];
	
	$resultado = iniciarSesion($usuario,$pass);

	if (count($resultado) > 0) {
		$msjError = "";
		$_SESSION["usuario"] = $resultado[0]["username"];
		$_SESSION["rol"] = $resultado[0]["rol"];
		$_SESSION["email"] = $resultado[0]["email"];
		$_SESSION["id"] = $resultado[0]["id"];
		require("backend.php");
	}
	else {
		$msjError = "<p>Usuario o password incorrecta</p>";
		require("login.php");
	}
?>