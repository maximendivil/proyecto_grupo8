<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$user =  $_GET["user"];

	$rows = obtenerResponsableUsuario($user);

	if (count($rows)>0){

		require("../vista/modificar_responsable.html");
	}
?>