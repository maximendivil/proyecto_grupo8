<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$exito = eliminarUsuario($_GET["user"],$_GET["valor"]);

	if ($exito){ //Si se ejecuto la consulta con exito
		header("Location: eliminar_cuenta.php");
	}
	else {
		//Manejar error de la db
	}
?>