<?php
	session_start();
	
	require("../modelo/modelo_funciones.php");
	
	$rows = obtenerUsuarios();
	
	if (count($rows)>0){		
		require("../vista/listados.html");
	}
?>