<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$titulo = obtenerInformacionTitulo();
	$email = obtenerInformacionMail();
	$telefono = obtenerInformacionTelefono();

	require("../vista/informacion.html");
?>