<?php
	session_start();

	require("../vista/menuConfiguracion.html");
?>