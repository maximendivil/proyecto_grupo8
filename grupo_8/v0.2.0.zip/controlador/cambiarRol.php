<?php
	session_start();
	
	require("../vista/cambiarRol.html");
?>