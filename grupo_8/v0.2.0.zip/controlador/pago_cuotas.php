<?php
	session_start();

	require("../modelo/modelo_funciones.php");
	/*$paginacion = cantidadPaginacionSitio();
	$idAlumno = $_GET["id"];
	$_SESSION["idAlumno"] = $idAlumno;
	$pagina = $_GET["pagina"];
	if (!$pagina) {
	   $inicio = 0;
	   $pagina = 1;
	}
	else {
	   $inicio = ($pagina - 1) * $paginacion;
	}*/
	$rows = totalCuotasImpagas($idAlumno);
	//$rows = buscarCuotasImpagasParaUnAlumno($idAlumno,$inicio,$paginacion);
	echo "Cantidad de cuotas: ".count($rows);
	//$total_paginas = ceil(count($total) / $paginacion);

	if (count($rows)<1){
		$msjError = "No tiene cuotas impagas";
	}		
	$rowsPagas = buscarCuotasPagas($idAlumno);
	if (count($rowsPagas)<1){
		$msjErrorPagas = "No tiene cuotas pagas";	
	}	

	require("../vista/pagarCuota.html");
?>