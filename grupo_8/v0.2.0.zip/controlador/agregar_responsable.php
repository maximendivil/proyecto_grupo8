<?php
	session_start();
	
	require("../modelo/modelo_funciones.php");
	
	$rows = obtenerUsuarios();
	
	require("../vista/listados.html");
?>