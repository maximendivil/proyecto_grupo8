<?php
    session_start();

	require("../modelo/modelo_funciones.php");
	
	/*$retorno = esResponsable($_SESSION["id"])
	if($retorno == true){
		$rows = obtenerCuotasImpagasPorAoM($_SESSION["id"]);
		if(count($rows)==0){
			$msjE = "<h3>No hay alumnos!</h3>";
		}
	}else{
		$msjE = "<h3>No es responsable!</h3>";
	}*/

	//Si es un usuario de consulta, solo puedo ver los alumnos que tengo a cargo
	if ($_SESSION["rol"] == "consulta"){
		$retorno = esResponsable($_SESSION["usuario"]);
		if (count($retorno)>0){
			$rows = obtenerCuotasImpagasPorAoM($retorno[0]["id"]);
			if(count($rows)==0){
				$msjE = "No hay alumnos!";
			}
		}
		else{
			$msjE = "No es responsable!";
		}
	}
	//Para el rol de administracion o de gestion, muestro todos los alumnos
	else {
		$rows = cuotasImpagas();
		if (count($rows)==0){
			$msjE = "No hay alumnos que hayan pagado o hayan sido becados";
		}		
	}
	
	require("../vista/VlistadoDeCuotasImpagasPorAoM.html");

?>