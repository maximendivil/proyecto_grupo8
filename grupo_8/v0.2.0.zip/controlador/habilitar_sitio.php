<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$habilitado = verificarSitioHabilitado();

	require("../vista/habilitar_sitio.html");
?>