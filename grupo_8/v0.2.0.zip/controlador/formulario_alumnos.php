<?php
	session_start();
	require("../vista/formulario.html");
?>