<?php

    session_start();

    require("../modelo/modelo_funciones.php");
    
    $idResponsable = $_GET["idResponsable"];
    
    $resultado = eliminarResponsable2($idResponsable);
		
	
	if($resultado){
		$msjExito = "<h3>Operación realizada con éxito!</h3>";
		require("../vista/exitoAlumno.html");		
	}
	else {
		require("../vista/errorEliminarResponsable.html");	
	}
?>