<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$user = $_GET["user"];
	$apellido = $_POST["apellidoTutor"];
	$nombre = $_POST["nombreTutor"];
	$tipo = $_POST["tipoParentezco"];
	$fechaNac = $_POST["fechaNac"];
	$sexo = $_POST["sexo"];
	$mail = $_POST["email"];
	$tel = $_POST["tel"];
	$direccion = $_POST["direccion"];

	$resultado = modificarResponsable($user,$apellido,$nombre,$tipo,$fechaNac,$sexo,$mail,$tel,$direccion);

	if ($resultado){
		$msjExito = "<h3>El responsable fue modificado correctamente!</h3>";
		require("../vista/exito.html");
	}
?>