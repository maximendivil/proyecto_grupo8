<?php
	session_start();

	if (isset($_SESSION["usuario"])){
		require '../vista/operaciones.html';
	}
	else {
		header("Location: index.php");
	}
?>