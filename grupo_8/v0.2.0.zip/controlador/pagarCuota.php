<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	/*$idCuota = $_GET["idCuota"];
	$idAlumno = $_SESSION["idAlumno"];

	$resultado = pagarCuota($idCuota,$idAlumno);

	if ($resultado){
		require("pago_cuotas.php");
	}*/
	$cuotas = $_POST["cuota"];
	$idAlumno = $_GET["id"];

	if (count($cuotas)==0){
		$_SESSION["error"] =  "Debe seleccionar al menos una cuota";
		header("Location: pago_cuotas.php?id=$idAlumno");
	}
	else {
		$_SESSION["error"] = "";
		if(isset($_POST["cobrar"])){
			foreach ($_POST["cuota"] as $cuota) {
				pagarCuota($cuota,$idAlumno);
			}
			header("Location: pago_cuotas.php?id=$idAlumno");
		}
		else {
			foreach ($_POST["cuota"] as $cuota) {
				becarCuota($cuota,$idAlumno);
			}
			header("Location: pago_cuotas.php?id=$idAlumno");
		}
	}
	

?>