<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$idAlumno = $_GET["id"];
        $dni = $_POST["dni"];
	$apellido = $_POST["apellido"];
	$nombre = $_POST["nombre"];
	$fechaNac = $_POST["fechaNac"];
	$sexo = $_POST["sexo"];
        $mail = $_POST["mail"];
        $direccion = $_POST["direccion"];
	$fechaIngreso = $_POST["fechaIngreso"];
        

	$resultado = modificarAlumno($idAlumno,$dni,$apellido,$nombre,$fechaNac,$sexo,$mail,$direccion,$fechaIngreso);
        
        var_dump($resultado);
        
        if ($resultado){
		$msjExito = "<h3>El alumno fue modificado correctamente!</h3>";
		require("../vista/exitoAlumno.html");
	}
?>