<?php        
    session_start();

	require("../modelo/modelo_funciones.php");
	
	//Si es un usuario de consulta, solo puedo ver los alumnos que tengo a cargo
	if ($_SESSION["rol"] == "consulta"){
		$retorno = esResponsable($_SESSION["usuario"]);
		if (count($retorno)>0){
			$rows = obtenerAlumnosConMatriculaPagaDeUnResponsable($retorno[0]["id"]);
			if(count($rows)==0){
				$msjE = "No hay alumnos!";
			}
		}
		else{
			$msjE = "No es responsable!";
		}
	}
	//Para el rol de administracion o de gestion, muestro todos los alumnos
	else {
		$rows = alumnosConMatriculaPaga();
		if (count($rows)==0){
			$msjE = "No hay alumnos que hayan pagado la matr&iacute;cula";
		}		
	}
	
	require("../vista/VlistadoDeAlumnosConMatriculaPaga.html");

?>