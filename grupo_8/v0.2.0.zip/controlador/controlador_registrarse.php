<?php
	require("../modelo/modelo_funciones.php");

	if ($_POST["pass1"] != $_POST["pass2"]){
		$msjError = "<p>Las contrase&ntilde;as no coinciden</p>";
		require 'registrarse.php';
	}
	else {
		$user = $_POST["user"];
		$pass = $_POST["pass1"];
		$mail = $_POST["mail"];
		$rol = "";
		switch ($_POST["rol"]) {
			case '0':
				$rol = "gestion";
				break;
			case '1':
				$rol = "administracion";
				break;
			case '2':
				$rol = "consulta";
				break;
		}

		$existe = verificarUsuario($user);

		if (! $existe) {
			$msjError = "";
			$resultado = registrar($user,$pass,$rol,$mail);
			if ($resultado){
				$msjExito = "<h3>El usuario '$user' fue creado exitosamente!</h3>";
				require '../vista/exito.html';
			}
			else {
				require '../vista/vista_reporteError.html';
			}
			
		}
		else {
			$msjError = "<p>El usuario ingresado ya se encuentra registrado</p>";
			require 'registrarse.php';
		}		
						
	
	}

?>