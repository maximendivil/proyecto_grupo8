<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$paginacion = establecerPaginacion($_POST["pag"]);

	header("Location: menu_configuracion.php");
?>