<?php

    session_start();

    require("../modelo/modelo_funciones.php");
    
    $idResponsable = $_GET["idResponsable"];
    $idAlumno = $_GET["idAlumno"];
    
    $resultado = eliminarAlumnoResponsable($idAlumno,$idResponsable);
		
	
	if($resultado){
		$msjExito = "<h3>Operación realizada con éxito!</h3>";
		require("../vista/exito.html");		
	}
	else {
		require("../vista/errorEliminarResponsableAlumno.html");	
	}
?>