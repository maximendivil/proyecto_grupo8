<?php

    session_start();
	
    $user = NULL;
	
    require("../vista/agregar_responsableGeneral.html");

?>