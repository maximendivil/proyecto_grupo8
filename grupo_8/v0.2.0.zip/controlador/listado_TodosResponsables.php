<?php

session_start();

	require("../modelo/modelo_funciones.php");

	$rows = obtenerResponsables();
	if(count($rows)==0){
		$msjE = "<h3>No hay responsables!</h3>";
	}
        
	require("../vista/listadoTodosResponsablesEliminar.html");
?>
