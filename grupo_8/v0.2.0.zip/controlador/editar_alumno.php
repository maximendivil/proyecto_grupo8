<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$idAlumno = $_GET["id"];

	$rows = obtenerAlumnoConId($idAlumno);
        
	if (count($rows)>0){
		require("../vista/form_editar_alumno.html");
	}
?>