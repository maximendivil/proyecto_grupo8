<?php
	session_start();

	require("../vista/mi_cuenta.html");
?>