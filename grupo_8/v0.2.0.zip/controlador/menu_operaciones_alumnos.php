<?php
	session_start();

	require("../vista/menu_operaciones_alumnos.html");
?>