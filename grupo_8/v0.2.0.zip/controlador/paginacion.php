<?php
	session_start();

	require("../modelo/modelo_funciones.php");
	
	$paginacion = cantidadPaginacionSitio();

	require("../vista/paginacion.html");
?>