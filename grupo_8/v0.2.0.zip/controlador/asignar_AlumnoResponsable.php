<?php
	session_start();
	
	require("../vista/listadoResponsables.html");
        
?>