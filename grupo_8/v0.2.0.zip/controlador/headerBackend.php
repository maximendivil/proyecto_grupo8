<!DOCTYPE html>
<head>
	<title>Inicio</title>	
	<link rel="stylesheet" type="text/css" media="(min-width: 376px)" href="../styles.css"> <!--probando-->
	<link rel="stylesheet" type="text/css" media="(max-width: 376px)" href="../stylesMoviles.css"> <!--probando-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<meta charset="UTF-8">
</head>
<body id="fondo">
	<div id="contenido">
		<div id="encabezado">
			<div id="titulo"> 
				<h1>Cooperativa de la Escuela Joaquín V. González</h1>
				<h5>Escuela de la Universidad Nacional de La Plata</h5>
			</div>
			<div id="login">
				<?php echo "<p>Hola, ".$_SESSION["usuario"]."!</p>"; ?>
				<p><a href="logout.php">Logout</a></p> 
			</div>
			<div id="fotoPortada">
				<img id="img" src="../fotoEscuela.jpg" alt="Frente de la escuela Anexa">
			</div>
			<div id="menu">
				<ul>
					<li><a href="../controlador/backend.php">Inicio</a></li>
					<?php
						if ($_SESSION["rol"] == "administracion"){
							//echo "<li><a href='mi_cuenta.php'>Mi cuenta</a></li>";
							echo "<li><a href='mi_cuenta.php'>Usuarios</a></li>";
                                                        echo "<li><a href='menu_operaciones_alumnos.php'>Alumnos</a></li>";
							echo "<li><a href='menu_pago_cuotas.php'>Cuotas y Matriculas</a></li>";
							echo "<li><a href='menu_configuracion.php'>Configuraci&oacute;n</a></li>";
						}
						if ($_SESSION["rol"] == "gestion"){
							echo "<li><a href='../controlador/menu_pago_cuotas.php'>Cuotas y Matriculas</a></li>";
						}						
					?>
					<li><a href='menu_listados.php'>Listados</a></li>
				</ul>
			</div>
		</div>