<?php
	session_start();
	
	require("../modelo/modelo_funciones.php");
		
	$rol = "";
	switch ($_POST["rol"]) {
		case '0':
			$rol = "gestion";
			break;
		case '1':
			$rol = "administracion";
			break;
		case '2':
			$rol = "consulta";
			break;
	}
	$user = $_GET["user"];
	$resultado = modificarRol($user,$rol);
	
	if($resultado){
		$msjExito = "<h3>El rol para el usuario '$user' fue modificado correctamente!</h3>";
		require("../vista/exito.html");
	}
?>