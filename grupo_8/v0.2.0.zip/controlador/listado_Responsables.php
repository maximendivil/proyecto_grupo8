<?php

session_start();

	require("../modelo/modelo_funciones.php");

        $idAlumno=$_GET["idAlumno"];
        
	$rows = obtenerResponsablesQueNoSeanDe($idAlumno);
	if(count($rows)==0){
		$msjE = "<h3>No hay responsables!</h3>";
	}
        
	require("../vista/listadoResponsables.html");
?>
