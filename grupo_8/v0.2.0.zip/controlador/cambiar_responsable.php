<?php
	session_start();
	
	require("../modelo/modelo_funciones.php");
	
	$rows = obtenerUsuariosResponsables();
	
	if(count($rows)==0){
		$msjE = "<h3>No hay usuarios relacionados a un responsable</h3>";
	}
	require("../vista/listadosResponsables.html");
?>