<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	if (isset($_POST["hab"])){
		$habilitado = habilitarSitio();
	}
	else {
		$habilitado = deshabilitarSitio();
	}

	header("Location: menu_configuracion.php");
?>