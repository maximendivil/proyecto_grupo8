<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$msj = verMensajeDeshabilitado();

	require("../vista/mensaje_deshabilitado.html");
?>