<?php
	session_start();

	require("../vista/menuPagoCuotas.html");
?>