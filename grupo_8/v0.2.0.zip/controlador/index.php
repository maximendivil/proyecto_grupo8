<?php
	require("../modelo/modelo_funciones.php");

	$habilitado = verificarSitioHabilitado();

	if ($habilitado){
		$titulo = obtenerInformacionTitulo();
		$email = obtenerInformacionMail();
		$telefono = obtenerInformacionTelefono();	
		require("../vista/vistaIndex.html");
	}
	else {
		$msj = verMensajeDeshabilitado();
		require("../vista/vistaDeshabilitado.html");
	}
?>