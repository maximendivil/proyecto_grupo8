<?php
	session_start();
	
	require("../vista/registrarse.html");
?>