<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$titulo = establecerInformacionTitulo($_POST["tit"]);
	$email = establecerInformacionMail($_POST["mail"]);
	$telefono = establecerInformacionTelefono($_POST["tel"]);

	header("Location: menu_configuracion.php");
?>