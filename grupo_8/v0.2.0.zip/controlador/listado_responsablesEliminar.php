<?php

session_start();

	require("../modelo/modelo_funciones.php");

        $idAlumno=$_GET["idAlumno"];
        
	$rows = obtenerResponsablesDe($idAlumno);
	if(count($rows)==0){
		$msjE = "<h3>No hay responsables de este alumno!</h3>";
	}
        
	require("../vista/listadoResponsablesEliminar.html");
?>
