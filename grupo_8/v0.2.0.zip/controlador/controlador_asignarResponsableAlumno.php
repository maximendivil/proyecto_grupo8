<?php

    session_start();

    require("../modelo/modelo_funciones.php");
    
    $idResponsable = $_GET["idResponsable"];
    $idAlumno = $_GET["idAlumno"];
    
    $resultado = asignarAlumnoResponsable($idAlumno,$idResponsable);
		
	
	if($resultado){
		$msjExito = "<h3>El responsable fue asignado correctamente al alumno!</h3>";
		require("../vista/exitoAlumno.html");		
	}
	else {
		require("../vista/errorAsignarResponsableAlumno.html");	
	}
?>