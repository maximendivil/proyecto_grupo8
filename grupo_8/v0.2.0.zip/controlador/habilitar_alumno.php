<?php
        session_start();

        require("../modelo/modelo_funciones.php");
        
        
	$exito = habilitarAlumno($_GET["id"]);

	if ($exito){ //Si se ejecuto la consulta con exito
		header("Location: listados.php");
	}
	else {
		//Manejar error de la db
	}
?>
