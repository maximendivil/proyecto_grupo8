<?php
	session_start();

	require("../modelo/modelo_funciones.php");

	$msj = establecerMensajeDeshabilitado($_POST["msj"]);

	header("Location: menu_configuracion.php");
?>